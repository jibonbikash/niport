<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/bootstrap/css/bootstrap.min.css') }}"/>
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/font-awesome/css/font-awesome.min.css') }}"/>
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/flag-icon/flag-icon.min.css') }}"/>
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/simple-line-icons/css/simple-line-icons.css') }}">
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/ionicons/css/ionicons.css') }}">
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/toastr/toastr.min.css') }}">
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/chartist/chartist.css') }}">
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/apex-chart/apexcharts.css') }}">
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/css/app.min.css') }}"/>
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/css/style.min.css') }}"/>
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/datepicker/css/datepicker.min.css') }}"/>
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/datatables/jquery.dataTables.min.css') }}"/>
<link type="text/css" rel="stylesheet" href="{{ asset('themes/metricaladmin/assets/plugins/datatables/extensions/dataTables.jqueryui.min.css') }}"/>
<link type="text/css" rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"/>



