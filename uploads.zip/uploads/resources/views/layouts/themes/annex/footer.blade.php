<footer class="footer">
    © 2018 Annex by Mannatthemes.
</footer>
