<script type="text/javascript" src="{{ asset('themes/annex/assets/js/jquery.min.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/popper.min.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/bootstrap.min.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/modernizr.min.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/detect.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/fastclick.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/jquery.slimscroll.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/jquery.blockUI.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/waves.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/jquery.nicescroll.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/skycons.min.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/plugins/skycons/skycons.min.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/plugins/raphael/raphael-min.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/plugins/morris/morris.min.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/pages/dashborad.js') }} "></script>
<script type="text/javascript" src="{{ asset('themes/annex/assets/js/app.js') }} "></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/offline-exporting.js"></script>
