<footer class="page-footer">
    <div class="pd-t-4 pd-b-0 pd-x-20">
        <div class="tx-10 tx-uppercase">


            <p class="pd-y-10 mb-0">
                <img src="{{ asset('/themes/metricaladmin/assets/images/niport_footer.jpg') }}" height="50">
                Copyright&copy; {{ date('Y') }} | All rights reserved.</p>
        </div>
    </div>
</footer>
