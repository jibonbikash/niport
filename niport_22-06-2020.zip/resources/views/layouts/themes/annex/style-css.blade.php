<link href="{{ asset('themes/annex/assets/plugins/morris/morris.css') }}" rel="stylesheet">
<link href="{{ asset('themes/annex/assets/css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('themes/annex/assets/css/icons.css') }}" rel="stylesheet">
<link href="{{ asset('themes/annex/assets/css/style.css') }}" rel="stylesheet">
